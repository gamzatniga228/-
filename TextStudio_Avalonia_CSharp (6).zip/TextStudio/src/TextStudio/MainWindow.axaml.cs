using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Media;
using Avalonia.Platform.Storage;
using Avalonia.Styling;
using TextStudio.Models;

namespace TextStudio;

public partial class MainWindow : Window
{
    private readonly List<DocumentModel> _documents = [];
    private bool _syncing;
    private bool _darkTheme;

    private TextBox? ActiveEditor => (DocumentsTabs.SelectedItem as TabItem)?.Content as TextBox;
    private DocumentModel? ActiveDocument => DocumentsTabs.SelectedItem is TabItem tab
        ? tab.Tag as DocumentModel : null;

    public MainWindow()
    {
        InitializeComponent();
        AddDocument();
        KeyDown += Window_KeyDown;
        Closed += (_, _) => SaveRecoveryCopies();
    }

    private void AddDocument(string? text = null, string? path = null)
    {
        var title = path is null ? "Без названия" : Path.GetFileName(path);
        var doc = new DocumentModel(title, path);
        _syncing = true;
        var editor = new TextBox
        {
            Text = text ?? "",
            AcceptsReturn = true,
            AcceptsTab = true,
            TextWrapping = TextWrapping.NoWrap,
            FontFamily = new FontFamily("Cascadia Code, Consolas, monospace"),
            FontSize = 16,
            Padding = new Thickness(18),
            HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Stretch,
            VerticalAlignment = Avalonia.Layout.VerticalAlignment.Stretch,
            Watermark = "Начните вводить текст..."
        };
        doc.IsDirty = false;
        editor.TextChanged += (_, _) =>
        {
            if (_syncing) return;
            doc.Text = editor.Text ?? "";
            UpdateStatus();
        };
        editor.AddHandler(KeyDownEvent, Editor_KeyDown, RoutingStrategies.Tunnel);
        var tab = new TabItem { Header = doc.DisplayTitle, Content = editor, Tag = doc };
        doc.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(DocumentModel.DisplayTitle))
                tab.Header = doc.DisplayTitle;
        };
        _documents.Add(doc);
        DocumentsTabs.Items.Add(tab);
        DocumentsTabs.SelectedItem = tab;
        _syncing = false;
        UpdateStatus();
    }

    private async void Open_Click(object? sender, RoutedEventArgs e)
    {
        var files = await StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Открыть документ",
            AllowMultiple = true,
            FileTypeFilter =
            [
                new FilePickerFileType("Текстовые файлы")
                { Patterns = ["*.txt", "*.md", "*.cs", "*.json", "*.xml", "*.html", "*.css", "*.js", "*.py", "*.log"] },
                new FilePickerFileType("Все файлы") { Patterns = ["*"] }
            ]
        });
        foreach (var file in files)
        {
            try
            {
                var path = file.TryGetLocalPath();
                if (path is null) continue;
                var content = await File.ReadAllTextAsync(path, Encoding.UTF8);
                AddDocument(content, path);
                var doc = ActiveDocument!;
                doc.IsDirty = false;
                StatusText.Text = $"Открыт: {Path.GetFileName(path)}";
            }
            catch (Exception ex) { await ShowError("Не удалось открыть файл", ex.Message); }
        }
    }

    private async void Save_Click(object? sender, RoutedEventArgs e) => await SaveActiveAsync();

    private async Task SaveActiveAsync()
    {
        var doc = ActiveDocument;
        if (doc is null) return;
        var editor = ActiveEditor;
        if (editor is null) return;

        string? path = doc.FilePath;
        if (path is null)
        {
            var file = await StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Сохранить документ",
                SuggestedFileName = doc.Title == "Без названия" ? "Документ.txt" : doc.Title,
                FileTypeChoices =
                [
                    new FilePickerFileType("Текстовый файл") { Patterns = ["*.txt"] },
                    new FilePickerFileType("Markdown") { Patterns = ["*.md"] },
                    new FilePickerFileType("Все файлы") { Patterns = ["*"] }
                ],
                DefaultExtension = "txt"
            });
            path = file?.TryGetLocalPath();
            if (path is null) return;
        }

        try
        {
            await File.WriteAllTextAsync(path, editor.Text ?? "", new UTF8Encoding(false));
            doc.FilePath = path;
            doc.Title = Path.GetFileName(path);
            doc.IsDirty = false;
            StatusText.Text = $"Сохранено: {doc.Title}";
        }
        catch (Exception ex) { await ShowError("Не удалось сохранить файл", ex.Message); }
    }

    private void New_Click(object? sender, RoutedEventArgs e) => AddDocument();

    private async void CloseTab_Click(object? sender, RoutedEventArgs e)
    {
        if (sender is not Button button || button.Tag is not TabItem tab) return;
        await CloseDocumentAsync(tab);
    }

    private async Task CloseDocumentAsync(TabItem tab)
    {
        if (tab.Tag is DocumentModel doc && doc.IsDirty)
        {
            var answer = await AskSaveChangesAsync(doc.Title);
            if (answer == "Отмена") return;
            if (answer == "Сохранить")
            {
                DocumentsTabs.SelectedItem = tab;
                await SaveActiveAsync();
                if (doc.IsDirty) return;
            }
        }
        DocumentsTabs.Items.Remove(tab);
        if (DocumentsTabs.Items.Count == 0) AddDocument();
    }

    private async Task<string> AskSaveChangesAsync(string title)
    {
        var dialog = new Window
        {
            Title = "Несохранённые изменения",
            Width = 390, Height = 160,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            CanResize = false
        };
        var result = "Отмена";
        var panel = new StackPanel { Margin = new Thickness(16), Spacing = 14 };
        panel.Children.Add(new TextBlock { Text = $"Сохранить изменения в документе «{title}»?" });
        var buttons = new StackPanel { Orientation = Avalonia.Layout.Orientation.Horizontal, Spacing = 8, HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right };
        foreach (var label in new[] { "Сохранить", "Не сохранять", "Отмена" })
        {
            var b = new Button { Content = label };
            b.Click += (_, _) => { result = label; dialog.Close(); };
            buttons.Children.Add(b);
        }
        panel.Children.Add(buttons);
        dialog.Content = panel;
        await dialog.ShowDialog(this);
        return result;
    }

    private async Task ShowError(string title, string message)
    {
        var dialog = new Window
        {
            Title = title, Width = 480, Height = 190,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Content = new StackPanel
            {
                Margin = new Thickness(16), Spacing = 14,
                Children =
                {
                    new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap },
                    new Button { Content = "Закрыть", HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Right }
                }
            }
        };
        if (dialog.Content is StackPanel p && p.Children[1] is Button b) b.Click += (_, _) => dialog.Close();
        await dialog.ShowDialog(this);
    }

    private void Tabs_SelectionChanged(object? sender, SelectionChangedEventArgs e) => UpdateStatus();

    private void UpdateStatus()
    {
        var editor = ActiveEditor;
        if (editor is null) return;
        var text = editor.Text ?? "";
        var words = text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries).Length;
        LineCountText.Text = $"Строк: {text.Count(c => c == '\n') + 1}";
        WordCountText.Text = $"Слов: {words}";
        CharCountText.Text = $"Символов: {text.Length}";
        var before = text[..Math.Clamp(editor.CaretIndex, 0, text.Length)];
        var line = before.Count(c => c == '\n') + 1;
        var lastNewLine = before.LastIndexOf('\n');
        var column = before.Length - lastNewLine;
        CaretText.Text = $"Строка {line}, столбец {column}";
    }

    private void ToggleSearch_Click(object? sender, RoutedEventArgs e)
    {
        SearchPanel.IsVisible = !SearchPanel.IsVisible;
        if (SearchPanel.IsVisible) FindBox.Focus();
    }

    private void FindNext_Click(object? sender, RoutedEventArgs e)
    {
        var editor = ActiveEditor;
        var query = FindBox.Text ?? "";
        if (editor is null || query.Length == 0) return;
        var text = editor.Text ?? "";
        var start = Math.Clamp(editor.SelectionEnd, 0, text.Length);
        var index = text.IndexOf(query, start, StringComparison.CurrentCultureIgnoreCase);
        if (index < 0) index = text.IndexOf(query, 0, StringComparison.CurrentCultureIgnoreCase);
        if (index >= 0) { editor.Focus(); editor.Select(index, query.Length); StatusText.Text = "Совпадение найдено"; }
        else StatusText.Text = "Совпадений не найдено";
    }

    private void Replace_Click(object? sender, RoutedEventArgs e)
    {
        var editor = ActiveEditor;
        if (editor is null || string.IsNullOrEmpty(FindBox.Text)) return;
        if (editor.SelectedText.Equals(FindBox.Text, StringComparison.CurrentCultureIgnoreCase))
        {
            var start = editor.SelectionStart;
            editor.SelectedText = ReplaceBox.Text ?? "";
            editor.Select(start, (ReplaceBox.Text ?? "").Length);
        }
        else FindNext_Click(sender, e);
    }

    private void ReplaceAll_Click(object? sender, RoutedEventArgs e)
    {
        var editor = ActiveEditor;
        if (editor is null || string.IsNullOrEmpty(FindBox.Text)) return;
        var oldText = editor.Text ?? "";
        var newText = oldText.Replace(FindBox.Text, ReplaceBox.Text ?? "", StringComparison.CurrentCultureIgnoreCase);
        editor.Text = newText;
        StatusText.Text = $"Заменено: {(oldText.Length - newText.Length) / Math.Max(1, FindBox.Text.Length)}";
    }

    private void Undo_Click(object? sender, RoutedEventArgs e) => ActiveEditor?.Undo();
    private void Redo_Click(object? sender, RoutedEventArgs e) => ActiveEditor?.Redo();

    private void FontSize_Changed(object? sender, SelectionChangedEventArgs e)
    {
        if (ActiveEditor is null || FontSizeBox.SelectedItem is not ComboBoxItem item) return;
        if (double.TryParse(item.Content?.ToString(), out var size)) ActiveEditor.FontSize = size;
    }

    private void Theme_Click(object? sender, RoutedEventArgs e)
    {
        _darkTheme = !_darkTheme;
        RequestedThemeVariant = _darkTheme ? ThemeVariant.Dark : ThemeVariant.Light;
    }

    private void Window_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyModifiers.HasFlag(KeyModifiers.Control))
        {
            switch (e.Key)
            {
                case Key.N: New_Click(this, new RoutedEventArgs()); e.Handled = true; break;
                case Key.O: Open_Click(this, new RoutedEventArgs()); e.Handled = true; break;
                case Key.S: Save_Click(this, new RoutedEventArgs()); e.Handled = true; break;
                case Key.F: ToggleSearch_Click(this, new RoutedEventArgs()); e.Handled = true; break;
                case Key.W:
                    if (DocumentsTabs.SelectedItem is TabItem tab) _ = CloseDocumentAsync(tab);
                    e.Handled = true; break;
                case Key.Z: Undo_Click(this, new RoutedEventArgs()); e.Handled = true; break;
                case Key.Y: Redo_Click(this, new RoutedEventArgs()); e.Handled = true; break;
            }
        }
    }

    private void Editor_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter || e.Key == Key.Back || e.Key == Key.Delete) UpdateStatus();
    }

    private void SaveRecoveryCopies()
    {
        try
        {
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "TextStudio", "Recovery");
            Directory.CreateDirectory(folder);
            foreach (var doc in _documents.Where(d => d.IsDirty))
            {
                var safe = string.Concat(doc.Title.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '_' : c));
                File.WriteAllText(Path.Combine(folder, safe + ".recovery.txt"), doc.Text);
            }
        }
        catch { /* Recovery must never prevent application shutdown. */ }
    }
}
