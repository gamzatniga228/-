using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace TextStudio.Models;

public sealed class DocumentModel : INotifyPropertyChanged
{
    private string _text = "";
    private string _title;
    private bool _isDirty;

    public DocumentModel(string title = "Без названия", string? filePath = null)
    {
        _title = title;
        FilePath = filePath;
    }

    public string Title
    {
        get => _title;
        set { _title = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayTitle)); }
    }

    public string? FilePath { get; set; }

    public string Text
    {
        get => _text;
        set { _text = value; IsDirty = true; OnPropertyChanged(); }
    }

    public bool IsDirty
    {
        get => _isDirty;
        set { _isDirty = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayTitle)); }
    }

    public string DisplayTitle => (IsDirty ? "● " : "") + Title;

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) =>
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
